#include <bits/stdc++.h>
using namespace std;

void selecctionSort(int A[],int n){
  int min, i,j,aux;
  for(i=0;i<n-1;i++){
    min=i;
    for(j=i+1;j<n;j++)
      if(A[min]>A[j])
        min=j;
    aux=A[min];
    A[min]=A[i];
    A[i]=aux;
  }
}

int main() {
  
  int n, q, k, quest;

  cin >> n;
  cin >> q;
  while(n!=0 && q!=0){
    int arreglo[n];
    for(int i=0; i<n; i++){
      cin >> arreglo[i];
    }
    selecctionSort(arreglo,n);
    
    for(int j=0; j<q; j++){
      cin >> quest;
      /*
      cout << lower_bound(0, n-1, quest);
      k = 0;
      while(arreglo[k] != quest){
        k++;
      }
      cout << quest << " found at " << k + 1 << endl;
      */
    }
  }

  
}