/*
Javiera Naranjo
Scarlett Ojeda
Rodolfo Seguel
*/
#include <iostream>
using namespace std;

int main() {
  
  int n, m;
  int k = 1;
  
  cin >> n >> m;
  while (n != 0 && m!=0){
    char tablero[n+2][m+2];
    int numeros[n+2][m+2];
  
    for(int i=1;i<n+1;i++){
      for(int j=1;j<m+1;j++){
        cin >> tablero[i][j];
      }
    }
  
    for(int i=0;i<n+2;i++){
      for(int j=0;j<m+2;j++){
        numeros[i][j]=0;
      }
    }

    for(int i = 0; i < n; i++){
      for (int j = 0; j < m; j++){
        if (tablero[i+1][j+1] == '*'){
          numeros[i+1][j] += 1;
          numeros[i][j+1] += 1;
          numeros[i+1][j+1] += 1;
          numeros[i-1][j-1] +=1;
          numeros[i-1][j] += 1;
          numeros[i][j-1] += 1;
          numeros[i+1][j-1] += 1;
          numeros[i-1][j+1] += 1;
        }
      }
    }

    cout << "\nField #" << k << ":\n";
    for(int i = 0; i < n; i++){
      for (int j = 0; j < m; j++){
        if (tablero[i+1][j+1] == '*'){
          cout<<'*';
        }
        else{
          cout << numeros[i][j];
        }
      }
      cout << endl;
    }
    cin >> n >> m;
    k++;
    }
  
  return 0;
}
