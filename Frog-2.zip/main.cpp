//Rodolfo Seguel, Javiera Naranjo y Scarlett Ojeda
#include <bits/stdc++.h>
using namespace std;


int calcular(int A[], int i, int k, int &dp){
  if(i==0){
    return 0;
  }
  if (i < 0){
    return 1e9;
  }
  else {
    int posibleMenor;
    int dif = abs(A[i-1] - A[i]);
    int menor = dif + calcular(A, i-1, k, dp);
    for(int j = 2; j <= k; j++){
      dif = abs(A[i-j] - A[i]);
      posibleMenor = dif + calcular(A, i-j, k, dp);
      if(posibleMenor < menor) menor = posibleMenor;
    }
    return menor;
  }
}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);

  int n, k; cin >> n; cin >> k;
  int dp[n];
  int Arr[n];
  for(int i = 0; i < n; i++){
    cin >> Arr[i];
  }

  cout << calcular(Arr, n-1, k, dp[n]) << endl;

  return 0;
}