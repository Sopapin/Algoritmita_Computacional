#include <bits/stdc++.h>
using namespace std;

void espacios(string n){
  

  bool a = true;

  for(int i=0; i<size(n); i++){
    if(n[i] == ' ' || n[i] == ',' || n[i] == '.' || n[i] == '?' || n[i] == '!'){
      a = false;
      if(n[i] == ' '){
        continue;
      }
    }
    if(!a && n[i] != ',' && n[i] != '.' && n[i] != '?'&& n[i] != '!' && n[i] != ' '){
      cout << ' ';
      a = true;
    }
    cout << n[i];
  }

}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  string n;
  getline (cin,n);
  
  espacios(n);
  
  cout << endl;
  
  return 0;
}

