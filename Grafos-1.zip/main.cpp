#include <bits/stdc++.h>
using namespace std;

bool areTFriends(vector<vector<int>> graph, int c, int d){
  for(int i = 0; i < graph[c].size(); i++){
    for(int j = 0; j < graph[d].size(); j++){
      if(graph[graph[c][i]] == graph[graph[d][j]]){
        return true;
      }
    }
  }
  return false;
}

int main() {

  int n,m,q,a,b,c,d;

  cin >> n >> m >> q;
  vector<vector<int>> graph(n);
  
  for(int i = 0; i < m; i++) {
    cin >> a >> b;
    graph[a].push_back(b);
    graph[b].push_back(a);
  }

  for(int i = 0; i < q; i++){
    cin >> c >> d;
    cout << (areTFriends(graph,c,d) ? 1 : 0) << endl;
  }
  
}
