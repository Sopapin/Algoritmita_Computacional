#include <bits/stdc++.h>
using namespace std;

int main() {
  int casos, n;
  string elstring;

  cin >> casos;
  for(int k = 0; k<casos; k++){
    cin >> n;
    cin >> elstring;
    for(int i = 0; i < n; i++){
      for(int j = i; j < i+n; j++){
        if(elstring[j] == '1'){
          cout << 1;
          break;
        }
        if(j == i+n-1){
          cout << 0;
        }
      }
    }
    cout << endl;
  }
}