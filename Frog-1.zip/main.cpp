#include <bits/stdc++.h>
using namespace std;


int calcular(int Arr[], int i, int &dp){
  if(i==0){
    return 0;
  }
  if (i < 0){
    return 1e9; 
  } 
  else {
    int x = abs(Arr[i-1]-Arr[i]);
    int primero = x + calcular(Arr, i-1,dp);
    
    x = abs(Arr[i-2]-Arr[i]);
    int segundo = x + calcular(Arr, i-2,dp);

    return primero < segundo ? primero : segundo;
  }
}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);

  int n, x; cin >> n;
  int dp[n];
  int Arr[n];
  for(int i = 0; i < n; i++){
    cin >> Arr[i];
  }

  cout << calcular(Arr,n-1,dp[n]) << endl;

  return 0;
}